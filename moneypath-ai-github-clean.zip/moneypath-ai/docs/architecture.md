# Architecture

MoneyPath AI follows a layered client-server architecture:

```text
User
  |
  v
HTML / Tailwind CSS / JavaScript
  |
  v
Flask Application Layer
  |---- Authentication (Firebase)
  |---- Financial analytics
  |---- Goal / transaction workflows
  |---- Chatbot / voice interaction
  |---- Scheme recommendation
  |
  v
PostgreSQL

AI & Analytics
  |---- Financial metrics
  |---- Semantic embeddings
  |---- Eligibility filtering
  |---- Similarity-based scheme matching
```

The recommendation workflow combines strict eligibility filtering with semantic similarity to provide personalized government-scheme suggestions and stores reasoning/confidence information for explainability.
