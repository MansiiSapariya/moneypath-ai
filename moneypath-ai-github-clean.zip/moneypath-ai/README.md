# MoneyPath AI

A multilingual, voice-assisted AI financial guidance platform designed to make personal finance, financial literacy, and government welfare schemes easier to understand and access.

MoneyPath AI combines financial data management, analytics, personalized scheme recommendations, and conversational assistance in a single web application. The platform is designed particularly with users who may face language, digital-literacy, or financial-literacy barriers in mind.

## Why this project?

Financial information is often fragmented, complex, and difficult to interpret. Users may also struggle to identify government schemes that are relevant to their financial and demographic profile.

MoneyPath AI addresses this problem by combining:

- Multilingual Hindi/English interaction
- Voice-assisted input and responses
- Financial profile and transaction tracking
- Goal management
- Financial analytics and health indicators
- Personalized government-scheme recommendations
- Explainable conversational assistance
- Financial literacy content

The project is intended as an educational and prototype decision-support system rather than a banking or transaction-execution platform.

## Core Features

### 1. Multilingual onboarding

Users can complete onboarding in Hindi or English and provide demographic and financial information needed for personalized analysis.

### 2. OTP-based authentication

Firebase Authentication is used for phone-number-based OTP login. The Flask backend verifies Firebase ID tokens before creating or authenticating application users.

### 3. Financial management

The platform supports tracking of:

- Income
- Expenses
- Transactions
- Loans
- Savings
- Financial goals

### 4. Financial analytics

The analytics layer derives indicators such as:

- Savings rate
- Expense ratio
- Financial health score
- Expense distribution
- Goal progress
- Potential overspending or financial-risk indicators

### 5. Government scheme recommendation

MoneyPath AI uses a hybrid recommendation approach:

```text
User Financial / Demographic Profile
              |
              v
     Strict Eligibility Filter
              |
              v
       Soft Matching Logic
              |
              v
 Semantic Similarity with Schemes
              |
              v
 Personalized Recommendations
              |
              v
 Reasoning + Confidence / Explainability
```

Strict eligibility checks consider attributes such as state, age, gender, occupation, income, social category, disability, and marital status when those constraints are available.

For non-strict matches, semantic similarity is used to identify contextually relevant schemes.

The semantic matching component uses the `all-MiniLM-L6-v2` sentence-transformer model.

### 6. AI chatbot

The conversational layer provides financial education and guidance using user context, financial metrics, recommendations, and literacy content.

Users can interact through text and voice, with responses available in the selected language.

### 7. Financial literacy hub

The application provides educational content covering basic financial concepts and budgeting, with Hindi/English accessibility.

### 8. Alerts and insights

The system can surface contextual alerts related to areas such as:

- Overspending
- Low savings
- Goal delays
- Financial risk indicators

## System Architecture

MoneyPath AI follows a layered client-server architecture:

```text
                    USER
                      |
                      v
          HTML / Tailwind / JavaScript
                      |
                      v
                Flask Backend
          /        |        |        \
         /         |        |         \
Authentication  Analytics  Chatbot  Recommendations
     |             |         |            |
  Firebase         |      Context       Hybrid
                   |      + Voice       Matching
                   v
              PostgreSQL
```

The architecture separates presentation, application/business logic, persistent data, and AI/analytics responsibilities.

See [`docs/architecture.md`](docs/architecture.md) for a simplified architecture diagram.

## Technology Stack

### Backend

- Python
- Flask
- Flask-SQLAlchemy
- PostgreSQL
- Firebase Admin SDK

### Frontend

- HTML5
- Tailwind CSS
- JavaScript
- Firebase Authentication

### AI / Analytics

- Sentence Transformers
- Scikit-learn
- NumPy
- Pandas
- Statsmodels
- TensorFlow (optional analytics/forecasting dependency)

### Voice

- gTTS
- pyttsx3

## Project Structure

```text
moneypath-ai/
│
├── README.md
├── LICENSE
├── .gitignore
├── .env.example
├── requirements.txt
├── package.json
├── package-lock.json
│
├── app.py
├── database.py
├── schemes.json
├── Literacy Content RBI.txt
│
├── docs/
│   └── architecture.md
│
├── templates/
│   ├── base.html
│   ├── home.html
│   ├── login.html
│   ├── onboarding.html
│   ├── onboarding_user.html
│   ├── onboarding_transactions.html
│   ├── onboarding_goals.html
│   ├── dashboard.html
│   ├── transactions.html
│   ├── profile.html
│   ├── chatbot.html
│   ├── learning_hub.html
│   ├── scheme_detail.html
│   └── not_found.html
│
├── static/
│   ├── css/
│   ├── js/
│   └── images/
│
└── utils/
    └── utils.py
```

## Installation

### 1. Clone the repository

```bash
git clone https://github.com/MansiiSapariya/moneypath-ai.git
cd moneypath-ai
```

### 2. Create a virtual environment

```bash
python -m venv .venv
```

Activate it on Windows:

```bash
.venv\Scripts\activate
```

On macOS/Linux:

```bash
source .venv/bin/activate
```

### 3. Install Python dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure environment variables

Copy `.env.example` to `.env` and provide your local PostgreSQL and Firebase configuration.

The repository intentionally does **not** include Firebase service-account credentials or database passwords.

For Firebase Admin authentication, provide a service-account JSON file locally and set:

```text
FIREBASE_CREDENTIALS=secrets/firebase-service-account.json
```

Do not commit this file.

### 5. Configure Firebase Web Authentication

The frontend Firebase configuration in `static/js/scripts.js` and the login template contains placeholders. Replace them with your own Firebase project's web configuration.

### 6. Configure PostgreSQL

Create a PostgreSQL database and set:

```text
DB_USER=postgres
DB_PASSWORD=your_postgres_password
DB_HOST=localhost
DB_PORT=5432
DB_NAME=postgres
```

### 7. Initialize the database

Run:

```bash
python database.py
```

The database script creates the application tables through Flask-SQLAlchemy.

### 8. Run the application

```bash
python app.py
```

Then open the local address displayed by Flask.

## Recommendation Engine

The scheme recommendation engine is one of the main technical components of the project.

It combines two forms of matching:

### Strict eligibility

Rules are applied when scheme eligibility constraints are explicitly available. These can include:

- State
- Age
- Gender
- Occupation
- Income
- Social category
- Disability status
- Marital status

### Semantic similarity

Scheme descriptions, benefits, categories, and related text are embedded using a sentence-transformer model. Cosine similarity is then used to identify schemes that are contextually related to the user's profile and needs.

This hybrid design attempts to balance **regulatory-style eligibility constraints** with **semantic relevance and inclusivity**.

## Data

The repository includes structured government-scheme information used by the recommendation engine and financial-literacy content used by the application.

The application does not connect to a live banking system and does not execute financial transactions.

## Security Notes

Before publishing this repository, make sure you never commit:

- Firebase service-account JSON files
- Database passwords
- `.env` files
- API tokens
- Private keys
- Production credentials
- User financial data

This repository includes `.gitignore` rules for common secret and environment files.

## Testing

The original project was validated primarily through manual and scenario-based testing. Testing covered functional workflows, integration behaviour, multilingual interaction, voice interaction, and validation of invalid or incomplete inputs.

Automated unit tests, large-scale load testing, and production-scale performance testing are outside the current prototype scope.

## Limitations

- The platform is a prototype rather than a production banking application.
- It does not perform real-time banking integration or automated financial transactions.
- Recommendation confidence was evaluated primarily at the prototype level.
- Government scheme information can change and should be verified against official sources before making real decisions.
- Real-world user studies and large-scale deployment were not conducted.
- Performance under high concurrent usage has not been established.

## Future Scope

Potential extensions include:

- Expense and goal forecasting using machine learning
- Seasonal spending analysis
- Personalized savings optimization
- Learning-based recommendation ranking
- Real-time synchronization with official government-scheme APIs
- Additional Indian languages
- Improved regional speech recognition
- Automated unit, integration, and security testing
- Load and stress testing
- Mobile application deployment
- Offline-first functionality

## Project Context

MoneyPath AI was developed as a data science and AI project focused on financial inclusion, personalized guidance, explainability, and accessible user interaction.

The project combines software engineering, data analytics, NLP/semantic matching, conversational AI, and user-centered design into one application.

## Author

**Mansi Sapariya**

MSc Data Science

[GitHub](https://github.com/MansiiSapariya) · [LinkedIn](https://www.linkedin.com/in/mansi-sapariya/)

## Disclaimer

MoneyPath AI is an educational/prototype financial decision-support system. It does not provide regulated financial advice, execute financial transactions, or guarantee eligibility for government schemes. Users should verify financial information and scheme eligibility through official sources before taking action.
